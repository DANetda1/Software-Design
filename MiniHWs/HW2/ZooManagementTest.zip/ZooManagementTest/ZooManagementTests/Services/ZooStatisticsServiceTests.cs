﻿using System;
using System.Collections.Generic;
using Moq;
using Xunit;
using ZooManagement.Domain.Entities;
using ZooManagement.Domain.Interfaces;
using ZooManagement.Application.Services;
using System.Reflection;

namespace ZooManagement.Tests.Services
{
    public class ZooStatisticsServiceTests
    {
        [Fact]
        public void GetStatistics_ShouldReturnCorrectCounts()
        {
            var animals = new List<Animal>
            {
                new Animal("Zebra", "Zebi", DateTime.UtcNow, Gender.Female, "Grass", Guid.NewGuid(), AnimalType.Herbivore, AnimalStatus.Healthy),
                new Animal("Tiger", "Tigo", DateTime.UtcNow, Gender.Male, "Meat", Guid.NewGuid(), AnimalType.Predator, AnimalStatus.Sick)
            };

            var enclosures = new List<Enclosure>
            {
                new Enclosure(EnclosureType.Herbivore, EnclosureHealthType.Healthy, 100, 5),
                new Enclosure(EnclosureType.Predator, EnclosureHealthType.Sick, 100, 5)
            };

            var feedings = new List<FeedingSchedule>
            {
                new FeedingSchedule(Guid.NewGuid(), DateTime.UtcNow, "Grass") { IsCompleted = true },
                new FeedingSchedule(Guid.NewGuid(), DateTime.UtcNow, "Meat") { IsCompleted = false }
            };

            var animalRepo = new Mock<IRepository<Animal>>();
            var enclosureRepo = new Mock<IRepository<Enclosure>>();
            var feedingRepo = new Mock<IRepository<FeedingSchedule>>();

            animalRepo.Setup(r => r.GetAll()).Returns(animals);
            enclosureRepo.Setup(r => r.GetAll()).Returns(enclosures);
            feedingRepo.Setup(r => r.GetAll()).Returns(feedings);

            var service = new ZooStatisticsService(animalRepo.Object, enclosureRepo.Object, feedingRepo.Object);
            var stats = service.GetStatistics();

            Assert.Equal(2, stats.TotalAnimals);
            Assert.Equal(2, stats.TotalEnclosures);
            Assert.Equal(1, stats.TotalFedAnimals);
            Assert.Equal(50, stats.HealthyPercentage);
            Assert.Equal(50, stats.SickPercentage);
        }
    }
}
