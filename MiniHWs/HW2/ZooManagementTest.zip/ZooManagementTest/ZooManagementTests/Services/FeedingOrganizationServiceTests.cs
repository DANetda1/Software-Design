﻿using System;
using System.Collections.Generic;
using Moq;
using Xunit;
using ZooManagement.Domain.Entities;
using ZooManagement.Domain.Interfaces;
using ZooManagement.Application.Services;

namespace ZooManagement.Tests.Services
{
    public class FeedingOrganizationServiceTests
    {
        [Fact]
        public void FeedAnimals_ShouldMarkFeedingAsCompleted_WhenTimeIsDue()
        {
            var feeding = new FeedingSchedule(Guid.NewGuid(), DateTime.UtcNow.AddMinutes(-10), "Meat");

            var repo = new Mock<IRepository<FeedingSchedule>>();
            repo.Setup(r => r.GetAll()).Returns(new List<FeedingSchedule> { feeding });

            var service = new FeedingOrganizationService(Mock.Of<IRepository<Animal>>(), repo.Object);
            service.FeedAnimals();

            Assert.True(feeding.IsCompleted);
        }
    }
}
