﻿using System;
using System.Collections.Generic;
using Moq;
using Xunit;
using ZooManagement.Domain.Entities;
using ZooManagement.Domain.Interfaces;
using ZooManagement.Application.Services;

namespace ZooManagement.Tests.Services
{
    public class AnimalTransferServiceTests
    {
        [Fact]
        public void TransferAnimal_ShouldMoveAnimal_WhenAllValid()
        {
            var animalId = Guid.NewGuid();
            var sourceEnclosureId = Guid.NewGuid();
            var targetEnclosureId = Guid.NewGuid();

            var animal = new Animal("Lion", "Simba", DateTime.UtcNow, Gender.Male, "Meat", sourceEnclosureId, AnimalType.Predator, AnimalStatus.Healthy);

            var sourceEnclosure = new Enclosure(EnclosureType.Predator, EnclosureHealthType.Healthy, 100, 10);
            sourceEnclosure.AddAnimal(animalId);

            var targetEnclosure = new Enclosure(EnclosureType.Predator, EnclosureHealthType.Healthy, 100, 10);

            var animalRepo = new Mock<IRepository<Animal>>();
            var enclosureRepo = new Mock<IRepository<Enclosure>>();

            animalRepo.Setup(r => r.GetById(animalId)).Returns(animal);
            enclosureRepo.Setup(r => r.GetById(sourceEnclosureId)).Returns(sourceEnclosure);
            enclosureRepo.Setup(r => r.GetById(targetEnclosureId)).Returns(targetEnclosure);

            var service = new AnimalTransferService(animalRepo.Object, enclosureRepo.Object);
            service.TransferAnimal(animalId, targetEnclosureId);

            Assert.Equal(targetEnclosureId, animal.EnclosureId);
        }
    }
}
