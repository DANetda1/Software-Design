﻿using System;
using System.Collections.Generic;
using System.Linq;
using ZooManagement.Domain.Interfaces;

namespace ZooManagement.Infrastructure.Repositories
{
    public class InMemoryRepository<T> : IRepository<T> where T : class
    {
        private readonly Dictionary<Guid, T> _storage = new();

        private Guid GetId(T entity)
        {
            var prop = typeof(T).GetProperty("Id");
            return (Guid)(prop?.GetValue(entity) ?? Guid.Empty);
        }

        public void Add(T entity)
        {
            var id = GetId(entity);
            _storage[id] = entity;
        }

        public T GetById(Guid id)
        {
            _storage.TryGetValue(id, out var entity);
            return entity;
        }

        public IEnumerable<T> GetAll()
        {
            return _storage.Values.ToList();
        }

        public void Remove(Guid id)
        {
            _storage.Remove(id);
        }

        public void Update(T entity)
        {
            var id = GetId(entity);
            if (_storage.ContainsKey(id))
            {
                _storage[id] = entity;
            }
        }
    }
}
