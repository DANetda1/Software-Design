﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ZooManagement.Application.DTOs
{
    public class AnimalDto
    {
        public Guid Id { get; set; }

        [Required(ErrorMessage = "Пожалуйста, заполните поле Species")]
        public string Species { get; set; }

        [Required(ErrorMessage = "Пожалуйста, заполните поле Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Пожалуйста, заполните поле BirthDate")]
        public DateTime BirthDate { get; set; }

        [Required(ErrorMessage = "Пожалуйста, заполните поле Gender")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Пожалуйста, заполните поле FavoriteFood")]
        public string FavoriteFood { get; set; }

        public string Status { get; set; }

        [Required(ErrorMessage = "Пожалуйста, укажите ID вольера")]
        public Guid EnclosureId { get; set; }

        [Required(ErrorMessage = "Пожалуйста, заполните поле Type")]
        public string Type { get; set; }
    }
}
