﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using ZooManagement.Domain.Entities;

namespace ZooManagement.Application.DTOs
{
    public class AddAnimalQueryDto
    {
        [Required]
        public string Species { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        [DefaultValue("2025-04-23T12:00:00Z")]
        public DateTime BirthDate { get; set; }

        [Required]
        public Gender Gender { get; set; }

        [Required]
        public string FavoriteFood { get; set; }

        [Required]
        public AnimalStatus Status { get; set; }

        [Required]
        public AnimalType Type { get; set; }

        [Required]
        public Guid EnclosureId { get; set; }
    }
}
