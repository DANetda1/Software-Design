﻿using System;
using System.Collections.Generic;

namespace ZooManagement.Application.DTOs
{
    public class ZooStatisticsDto
    {
        public int TotalAnimals { get; set; }
        public int TotalEnclosures { get; set; }
        public Dictionary<string, int> AnimalsByType { get; set; }
        public double HealthyPercentage { get; set; }
        public double SickPercentage { get; set; }
        public int TotalFedAnimals { get; set; }
    }
}
