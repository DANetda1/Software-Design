using System;
using System.Collections.Generic;
using System.Linq;
using ZooManagement.Domain.Entities;
using ZooManagement.Domain.Interfaces;

namespace ZooManagement.Application.Services
{
    public class FeedingOrganizationService
    {
        private readonly IRepository<Animal> _animalRepository;
        private readonly IRepository<FeedingSchedule> _feedingRepository;

        public FeedingOrganizationService(IRepository<Animal> animalRepo, IRepository<FeedingSchedule> feedingRepo)
        {
            _animalRepository = animalRepo;
            _feedingRepository = feedingRepo;
        }

        public void AddFeeding(Guid animalId, DateTime time, string food)
        {
            var schedule = new FeedingSchedule(animalId, time, food);
            _feedingRepository.Add(schedule);
        }

        public void FeedAnimals()
        {
            var schedules = _feedingRepository.GetAll()
                .Where(f => !f.IsCompleted && f.FeedingTime <= DateTime.UtcNow)
                .ToList();

            foreach (var schedule in schedules)
            {
                schedule.MarkCompleted();
                _feedingRepository.Update(schedule);
            }
        }

        public IEnumerable<FeedingSchedule> GetFeedingSchedule()
        {
            return _feedingRepository.GetAll();
        }
    }
}
