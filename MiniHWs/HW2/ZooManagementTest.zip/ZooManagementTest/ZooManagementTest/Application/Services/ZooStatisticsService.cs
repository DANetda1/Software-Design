using System;
using System.Collections.Generic;
using System.Linq;
using ZooManagement.Application.DTOs;
using ZooManagement.Domain.Entities;
using ZooManagement.Domain.Interfaces;

namespace ZooManagement.Application.Services
{
    public class ZooStatisticsService
    {
        private readonly IRepository<Animal> _animalRepository;
        private readonly IRepository<Enclosure> _enclosureRepository;
        private readonly IRepository<FeedingSchedule> _feedingRepository;

        public ZooStatisticsService(
            IRepository<Animal> animalRepo,
            IRepository<Enclosure> enclosureRepo,
            IRepository<FeedingSchedule> feedingRepo)
        {
            _animalRepository = animalRepo;
            _enclosureRepository = enclosureRepo;
            _feedingRepository = feedingRepo;
        }

        public ZooStatisticsDto GetStatistics()
        {
            var animals = _animalRepository.GetAll().ToList();
            var enclosures = _enclosureRepository.GetAll().ToList();
            var feedings = _feedingRepository.GetAll().ToList();

            var animalsByType = animals
                .GroupBy(a => a.Type.ToString())
                .ToDictionary(g => g.Key, g => g.Count());

            var total = animals.Count;
            var healthy = animals.Count(a => a.Status == AnimalStatus.Healthy);
            var sick = animals.Count(a => a.Status == AnimalStatus.Sick);

            var totalFed = feedings.Count(f => f.IsCompleted);

            return new ZooStatisticsDto
            {
                TotalAnimals = total,
                TotalEnclosures = enclosures.Count,
                AnimalsByType = animalsByType,
                HealthyPercentage = total == 0 ? 0 : Math.Round((double)healthy / total * 100, 2),
                SickPercentage = total == 0 ? 0 : Math.Round((double)sick / total * 100, 2),
                TotalFedAnimals = totalFed
            };
        }
    }
}
