﻿using Microsoft.AspNetCore.Mvc;
using ZooManagement.Application.Services;

namespace ZooManagement.Presentation.Controllers
{
    [ApiController]
    [Route("api/statistics")]
    public class StatisticsController : ControllerBase
    {
        private readonly ZooStatisticsService _statisticsService;

        public StatisticsController(ZooStatisticsService statisticsService)
        {
            _statisticsService = statisticsService;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var stats = _statisticsService.GetStatistics();
            return Ok(stats);
        }
    }
}
