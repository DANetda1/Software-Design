﻿using Microsoft.AspNetCore.Mvc;
using ZooManagement.Application.Services;
using System;

namespace ZooManagement.Presentation.Controllers
{
    [ApiController]
    [Route("api/transfer")]
    public class TransferController : ControllerBase
    {
        private readonly AnimalTransferService _transferService;

        public TransferController(AnimalTransferService transferService)
        {
            _transferService = transferService;
        }

        [HttpPost]
        public IActionResult Transfer([FromQuery] Guid animalId, [FromQuery] Guid targetEnclosureId)
        {
            try
            {
                _transferService.TransferAnimal(animalId, targetEnclosureId);
                return Ok("Животное успешно перемещено.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
