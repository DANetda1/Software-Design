using Microsoft.AspNetCore.Mvc;
using ZooManagement.Application.Services;
using System;
using ZooManagement.Domain.Entities;

namespace ZooManagement.Presentation.Controllers
{
    [ApiController]
    [Route("api/feeding")]
    public class FeedingController : ControllerBase
    {
        private readonly FeedingOrganizationService _service;

        public FeedingController(FeedingOrganizationService service)
        {
            _service = service;
        }

        [HttpPost("add")]
        public IActionResult AddFeeding([FromQuery] Guid animalId, [FromQuery] DateTime time, [FromQuery] string food)
        {
            _service.AddFeeding(animalId, time, food);
            return Ok();
        }

        [HttpPost("feed")]
        public IActionResult FeedAnimals()
        {
            _service.FeedAnimals();
            return Ok();
        }

        [HttpGet("schedule")]
        public IActionResult GetFeedingSchedule()
        {
            var schedule = _service.GetFeedingSchedule();
            return Ok(schedule);
        }
    }
}
