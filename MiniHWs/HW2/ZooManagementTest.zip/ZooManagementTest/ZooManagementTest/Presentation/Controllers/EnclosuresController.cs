using Microsoft.AspNetCore.Mvc;
using ZooManagement.Domain.Entities;
using ZooManagement.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ZooManagement.Presentation.Controllers
{
    [ApiController]
    [Route("api/enclosures")]
    public class EnclosuresController : ControllerBase
    {
        private readonly IRepository<Enclosure> _repository;

        public EnclosuresController(IRepository<Enclosure> repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_repository.GetAll());
        }

        [HttpPost]
        public IActionResult Add([FromQuery] int size, [FromQuery] int maxCapacity, [FromQuery] EnclosureType type, [FromQuery] EnclosureHealthType healthType)
        {
            var enclosure = new Enclosure(type, healthType, size, maxCapacity);
            _repository.Add(enclosure);
            return Ok(enclosure);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(Guid id)
        {
            _repository.Remove(id);
            return NoContent();
        }
    }
}
