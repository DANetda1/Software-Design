﻿using System;
using System.Collections.Generic;

namespace ZooManagement.Domain.Interfaces
{
    public interface IRepository<T>
    {
        T GetById(Guid id);
        IEnumerable<T> GetAll();
        void Add(T entity);
        void Remove(Guid id);
        void Update(T entity);
    }
}
