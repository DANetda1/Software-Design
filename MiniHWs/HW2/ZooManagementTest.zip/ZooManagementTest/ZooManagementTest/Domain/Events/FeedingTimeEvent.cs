using System;

namespace ZooManagement.Domain.Events
{
    public class FeedingTimeEvent
    {
        public Guid FeedingScheduleId { get; }
        public DateTime ScheduledTime { get; }

        public FeedingTimeEvent(Guid feedingScheduleId, DateTime scheduledTime)
        {
            FeedingScheduleId = feedingScheduleId;
            ScheduledTime = scheduledTime;
        }
    }
}
