using System;

namespace ZooManagement.Domain.Events
{
    public class AnimalMovedEvent
    {
        public Guid AnimalId { get; }
        public Guid FromEnclosureId { get; }
        public Guid ToEnclosureId { get; }
        public DateTime MovedAt { get; }

        public AnimalMovedEvent(Guid animalId, Guid fromEnclosureId, Guid toEnclosureId)
        {
            AnimalId = animalId;
            FromEnclosureId = fromEnclosureId;
            ToEnclosureId = toEnclosureId;
            MovedAt = DateTime.UtcNow;
        }
    }
}
