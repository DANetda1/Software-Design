using System;

namespace ZooManagement.Domain.Entities
{
    public enum Gender
    {
        Male,
        Female
    }

    public enum AnimalStatus
    {
        Healthy,
        Sick
    }

    public enum AnimalType
    {
        Predator,
        Herbivore,
        Bird,
        Aquarium
    }

    public class Animal
    {
        public Guid Id { get; private set; }
        public string Species { get; private set; }
        public string Name { get; private set; }
        public DateTime BirthDate { get; private set; }
        public Gender Gender { get; private set; }
        public string FavoriteFood { get; private set; }
        public AnimalStatus Status { get; private set; }
        public Guid EnclosureId { get; private set; }
        public AnimalType Type { get; private set; }

        public Animal(string species, string name, DateTime birthDate, Gender gender, string favoriteFood, Guid enclosureId, AnimalType type, AnimalStatus status)
        {
            Id = Guid.NewGuid();
            Species = species;
            Name = name;
            BirthDate = birthDate;
            Gender = gender;
            FavoriteFood = favoriteFood;
            EnclosureId = enclosureId;
            Type = type;
            Status = status;
        }

        public void MoveToEnclosure(Guid newEnclosureId)
        {
            EnclosureId = newEnclosureId;
        }
    }
}
