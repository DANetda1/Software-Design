using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ZooManagement.Domain.Entities
{
    public enum EnclosureType
    {
        Predator,
        Herbivore,
        Bird,
        Aquarium
    }

    public enum EnclosureHealthType
    {
        Healthy,
        Sick
    }

    public class Enclosure
    {
        public Guid Id { get; private set; }
        public EnclosureType Type { get; private set; }
        public EnclosureHealthType HealthType { get; private set; }
        public int Size { get; private set; }
        public int MaxCapacity { get; private set; }
        private readonly List<Guid> _animalIds;

        public IReadOnlyList<Guid> AnimalIds => _animalIds.AsReadOnly();

        public Enclosure(EnclosureType type, EnclosureHealthType healthType, int size, int maxCapacity)
        {
            Id = Guid.NewGuid();
            Type = type;
            HealthType = healthType;
            Size = size;
            MaxCapacity = maxCapacity;
            _animalIds = new List<Guid>();
        }

        public bool AddAnimal(Guid animalId)
        {
            if (_animalIds.Count >= MaxCapacity) return false;
            _animalIds.Add(animalId);
            return true;
        }

        public bool RemoveAnimal(Guid animalId)
        {
            return _animalIds.Remove(animalId);
        }

        public void Clean()
        {
            Console.WriteLine($"������ {Id} ������.");
        }
    }
}
