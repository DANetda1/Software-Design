﻿namespace ZooManagement.Domain.ValueObjects
{
    public enum AnimalStatus
    {
        Healthy,
        Sick
    }
}
